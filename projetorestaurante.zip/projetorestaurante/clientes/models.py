from django.db import models

class Pessoa(models.Model):
    nome = models.CharField(max_length=50)
    telefone = models.CharField(max_length=11)  # ← CharField é melhor que IntegerField
    email = models.EmailField(max_length=100)   # ← campo próprio para email
    quantidade = models.PositiveIntegerField()  # ← melhor para valores positivos (sem max_length)
    data_criacao = models.DateTimeField(auto_now_add=True)  

    def __str__(self):
        return self.nome
from django.urls import path
from . import views

urlpatterns = [
    path('', views.controle, name='controle'),         # Página principal do restaurante
    path('proximo/<int:id>/', views.proximo, name='proximo'), # Passa para o próximo cliente
]

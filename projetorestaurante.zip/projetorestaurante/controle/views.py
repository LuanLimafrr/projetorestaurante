from django.shortcuts import render, redirect
from clientes.models import Pessoa  # Importa o model do app clientes


def controle(request):
    clientes = Pessoa.objects.all().order_by('data_criacao')
    return render(request, "controle/templates/restaurante.html", {"clientes": clientes})

def proximo(request, id):
    cliente = Pessoa.objects.get(id=id)
    cliente.delete()  # Remove da fila
    return redirect('controle')
